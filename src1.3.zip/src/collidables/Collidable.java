package collidables;

import ballattributes.Velocity;
import ballattributes.Ball;
import gameopperating.GameLevel;
import geometricshapes.Point;
import geometricshapes.Rectangle;
import listeners.HitListener;

/**
 * interface for objects that can be collide with.
 */
public interface Collidable {
    /**
     * return the "collision shape" of the object.
     *
     * @return the collision shape.
     */
    Rectangle getCollisionRectangle();

    /**
     *
     * @param hitter
     */
    void hit(Ball hitter);

    void removeFromGame(GameLevel g);

    void removeHitListener(HitListener h);

    boolean isAlien();



}
