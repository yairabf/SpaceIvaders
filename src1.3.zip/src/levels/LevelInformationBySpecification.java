package levels;

import animations.FormationCharge;
import collidables.Block;
import gameopperating.Counter;
import sprites.Sprite;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.InputStream;
import java.util.*;
import java.util.List;

/**
 * Class that represent an object that hold the level information.
 */
public class LevelInformationBySpecification implements LevelInformation {
    private String levelName;
    private FormationCharge formationCharge;
    private double speed;
    private boolean empty;
    private int startX = 10;
    private int startY = 30;



    /**
     * constructor.
     */
    public LevelInformationBySpecification() {
        this.speed = 2;
        this.formationCharge = new FormationCharge(this.aliensFormation(), this.speed,
                this.getStartX(), this.getStartY());
        this.empty = formationCharge.isEmpty();
        //this.startX = 10;
        //this.startY = 30;
    }
    /**
     * @param l is the name of the level.
     */
    public void setLevelName(String l) {
        this.levelName = l;
    }

    /**
     *
     * @param movementSpeed
     */
    public void setMovementSpeed(int movementSpeed) {
        this.speed = movementSpeed;
    }

    @Override
    public void setLevelName(int i) {
        this.levelName = "Level "+i;
    }

    /**
     * @return the level name.
     */
    @Override
    public String levelName() {
        return this.levelName;
    }

    /**
     * @return the background.
     */
    @Override
    public Sprite getBackground() {
        return new Block(0,0,800,600, Color.black,-1);
    }


    /**
     * @return the list of blocks.
     */
    public List<List<Block>> aliensFormation() {
        List<List<Block>> formation = new LinkedList<>();
        for(int i = 0; i < 10 ; i++){//***************************************************************changed here to 1 need to be i<5
            formation.add(i, this.aliensColumn(this.getStartX() + 50 * i, this.getStartY()));
        }
        return formation;
     }

    /**
     * @return the number of blocks to remove.
     */
    @Override
    public int numberOfBlocksToRemove() {
        return 50;
    }//***********************************************changed here to 1 instead of 50

    /**
     * @return the starting x axis for te point.
     */
    public int getStartX() {
        return this.startX;
    }

    /**
     * @return the starting y axis for te point.
     */
    public int getStartY() {
        return this.startY;
    }

    /**
     * @return the row height.
     */
    public int getRowHeight() {
        return 30;
    }

    private List<Block> aliensColumn(int x, int y) {
        InputStream image =
                ClassLoader.getSystemClassLoader().
                        getResourceAsStream("block_images/enemy.png");
        Image img = null;
        try {
            img = ImageIO.read(image);
        } catch (Exception e) {
            e.printStackTrace();
        }
        List<Block> column = new ArrayList<>();
        for(int i = 0; i < 5; i++) {//***************************************************************changed here to 1 need to be i<10
            Block alien = new Block(x, y + (40 * i), 40, 30, Color.BLUE, 1);
            alien.setImage(img);
            alien.setAlien(true);
            column.add(alien);
        }
        return column;
    }

    /**
     *
     * @return
     */
    public double getSpeed() {
        return speed;
    }

    /**
     *
     * @return the formation charge.

     */
    public FormationCharge getFormationCharge(){
        return this.formationCharge;
    }

    /**
     * checks if the formation is empty.
     * @return true or false.
     */
    @Override
    public boolean isEmpty() {
        return this.empty;
    }

    @Override
    public void setEmpty(boolean t) {
        this.empty = t;
    }

    @Override
    public void initEmptinnes() {
        this.empty = true;
    }

    @Override
    public void resetAliensFormation(){
        this.startX = 10;
        this.startY = 30;
        this.formationCharge = new FormationCharge(this.aliensFormation(), this.speed,
                this.startX, this.startY);
    }

    @Override
    public void setFormationSpeed(double s) {
        this.speed = s;
    }
}
