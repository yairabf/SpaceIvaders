package animations;

import ballattributes.Ball;
import ballattributes.Velocity;
import biuoop.DrawSurface;
import collidables.Block;
import gameopperating.GameEnvironment;
import gameopperating.GameLevel;
import geometricshapes.Point;
import listeners.HitListener;
import listeners.HitNotifier;
import sprites.Sprite;

import javax.imageio.ImageIO;
import javax.swing.text.Highlighter;
import java.awt.*;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Class
 */
public class FormationCharge implements Sprite, HitNotifier {
    private Map<Integer, List<Block>> formation;
    private int speed;
    private GameEnvironment gameEnvironment;
    private double startX;
    private double startY;


    /**
     * 
     * @param formation
     * @param speed
     * @param startX
     * @param startY
     */
    public FormationCharge(Map<Integer, List<Block>> formation, int speed, double startX, double startY) {
        this.formation = formation;
        this.speed = speed;
        this.startX = startX;
        this.startY = startY;

    }

    /**
     * the method moving all the aliens right.
     */
    public void moveRight() {
        double nextX = this.getMostRight() + this.speed;
        if (nextX >= 800) {
            this.setYForAllBlocks();
            this.speed *= -1;
        } else {
            this.setXForAllBlocks();
        }
    }

    /**
     * the method moving all the aliens left.
     */
    public void moveLeft() {
        double nextX = this.getMostLeft() + this.speed;
        if (nextX <= 0) {
            this.setYForAllBlocks();
            this.speed *= -1;
        } else {
            this.setXForAllBlocks();
        }
    }

    /**
     * the method set all the block new location according to theirs 'x' value.
     */
    private void setXForAllBlocks() {
        for (int i = 0; i < this.formation.size(); i++) {
            for (Block block : formation.get(i)) {
                double nextX = block.getRect().getUpperLeft().getX() + this.speed;
                block.getRect().setTopLeftX(nextX);
            }
        }
    }

    /**
     * the method set all the block new location according to theirs 'y' value.
     */
    private void setYForAllBlocks() {
        for (int i = 0; i < this.formation.size(); i++) {
            for (Block block : formation.get(i)) {
                block.getRect().setTopLeftX(block.getRect().getHeight() / 2);
            }
        }
    }

    /**
     * the method create balls from the columns locations and shoots them.
     */
    public void shootingBalls() {
        Random random = new Random();
        int column = random.nextInt(this.formation.size());
        Block lowestBlockInColumn = this.formation.get(column).get(this.formation.get(column).size());
        double xLocation = lowestBlockInColumn.getRect().getUpperLeft().getX()
                + lowestBlockInColumn.getRect().getWidth() / 2;
        double yLocation = lowestBlockInColumn.getRect().getUpperLeft().getY()
                + lowestBlockInColumn.getRect().getHeight() + 10;
        Point location = new Point(xLocation, yLocation);
        Ball shootingBall = new Ball(location, 3, Color.RED);
        Velocity velocity = Velocity.fromAngleAndSpeed(0, 350);
        shootingBall.setVelocity(velocity);
        shootingBall.setGame(this.gameEnvironment);
    }

    /**
     * the method returns the 'x' value of the most left block's location.
     *
     * @return the 'x' value of the most left block's location.
     */
    private double getMostLeft() {
        return this.formation.get(this.formation.size()).get(0).getRect().getUpperLeft().getX()
                + this.formation.get(this.formation.size()).get(0).getRect().getWidth();
    }

    /**
     * @return
     */
    private double getMostRight() {
        return this.formation.get(0).get(0).getRect().getUpperLeft().getX();
    }

    /**
     * the method returns the location that the lowest block reach.
     *
     * @return the location that the lowest block reach.
     */
    public double getMostDown() {
        double mostDown = 0;
        for (int i = 0; i < this.formation.size(); i++) {
            Block currentMostDownBlock = this.formation.get(i).get(this.formation.get(i).size());
            double currentMostDownLocation = currentMostDownBlock.getRect().getUpperLeft().getY()
                    + currentMostDownBlock.getRect().getHeight();
            if (currentMostDownLocation >= mostDown) {
                mostDown = currentMostDownLocation;
            }
        }
        return mostDown;
    }

    @Override
    public void drawOn(DrawSurface d) {
        for (int i = 0; i < this.formation.size(); i++) {
            for (Block block : this.formation.get(i)) {
                block.drawOn(d);
            }
        }
    }

    @Override
    public void timePassed(double dt) {
        long currentTime = 0;
        if (this.speed > 0) {
            this.moveLeft();
        } else {
            this.moveRight();
        }
        currentTime += dt;
        if (currentTime >= 0.5) {
            this.shootingBalls();
        }
    }


    @Override
    public void addToGame(GameLevel g) {
        g.addSprite(this);
        for (int i = 0; i < this.formation.size(); i++) {
            for (Block block : this.formation.get(i)) {
                g.addCollidable(block);
            }
        }
    }

    @Override
    public void addHitListener(HitListener hl) {
        for (int i = 0; i < this.formation.size(); i++) {
            for (Block block : this.formation.get(i)) {
                block.addHitListener(hl);
            }
        }
    }

    @Override
    public void removeHitListener(HitListener hl) {
        for (int i = 0; i < this.formation.size(); i++) {
            for (Block block : this.formation.get(i)) {
                block.removeHitListener(hl);
            }
        }
    }

    /**
     * thew method set the game environment for the formation charge
     * @param game game environment.
     */
    public void setGameEnvironment(GameEnvironment game) {
        this.gameEnvironment = game;
    }

    /**
     * the method set the formation at the start location.
     */
    public void setStartFormation() {
        for (int i = 0; i < this.formation.size(); i++) {
            for (int j = 0; j < 5; j++) {
                this.formation.get(i).get(j).getRect().setTopLeftX(this.startX + 50 * i);
                this.formation.get(i).get(j).getRect().setTopLeftY(this.startX + 40 * j);

            }
        }
    }
}
