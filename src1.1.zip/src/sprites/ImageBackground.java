package sprites;

import biuoop.DrawSurface;
import gameopperating.GameLevel;

import java.awt.Image;

/**
 * Class that represent image for the background.
 */
public class ImageBackground implements Sprite {
    private Image image;
    private int x;
    private int y;

    /**
     * constructor.
     *
     * @param im is the image for the background.
     * @param x  is the x axis of where it starts.
     * @param y  is the y axis of where it starts.
     */
    public ImageBackground(Image im, int x, int y) {
        this.image = im;
        this.x = x;
        this.y = y;
    }

    @Override
    public void drawOn(DrawSurface d) {
        d.drawImage(this.x, this.y, this.image);
    }

    @Override
    public void timePassed(double dt) {

    }

    @Override
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }
}
