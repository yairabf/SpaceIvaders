package levels;

import animations.FormationCharge;
import collidables.Block;
import sprites.Sprite;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Class that represent an object that hold the level information.
 */
public class LevelInformationBySpecification implements LevelInformation {
    private String levelName;
    private int movementSpeed;


    /**
     * @param l is the name of the level.
     */
    public void setLevelName(String l) {
        this.levelName = l;
    }

    /**
     *
     * @param movementSpeed
     */
    public void setMovementSpeed(int movementSpeed) {
        this.movementSpeed = movementSpeed;
    }

    /**
     * @return the level name.
     */
    @Override
    public String levelName() {
        return this.levelName;
    }

    /**
     * @return the background.
     */
    @Override
    public Sprite getBackground() {
        return new Block(0,0,800,600, Color.black,-1);
    }


    /**
     * @return the list of blocks.
     */
    public Map<Integer, List<Block>> aliensFormation() {
        Map<Integer, List<Block>> formation = new TreeMap<>();
        for(int i=0;i<10;i++){
            formation.put(i,this.aliensColumn(this.getStartX()*i, this.getStartY()));
        }
        return formation;
     }

    /**
     * @return the number of blocks to remove.
     */
    @Override
    public int numberOfBlocksToRemove() {
        return 50;
    }

    /**
     * @return the starting x axis for te point.
     */
    public int getStartX() {
        return 10;
    }

    /**
     * @return the starting y axis for te point.
     */
    public int getStartY() {
        return 30;
    }

    /**
     * @return the row height.
     */
    public int getRowHeight() {
        return 30;
    }

    private List<Block> aliensColumn(int x, int y) {
        InputStream image =
                ClassLoader.getSystemClassLoader().
                        getResourceAsStream("block_images//enemy.png");
        Image img = null;
        try {
            img = ImageIO.read(image);
        } catch (Exception e) {
            e.printStackTrace();
        }
        List<Block> column = new ArrayList<>();
        for(int i = 0; i < 5; i++) {
            Block alien = new Block(x, y + (30 * i + 10), 40, 30, Color.BLUE, 1);
            alien.setImage(img);

        }
        return column;
    }

    /**
     *
     * @return
     */
    public FormationCharge formationCharge(){
        return new FormationCharge(this.aliensFormation(), this.movementSpeed, this.getStartX(), this.getStartY());
    }
}
