package levels;

import animations.FormationCharge;
import collidables.Block;
import sprites.Sprite;

import java.util.List;
import java.util.Map;

/**
 * an interface giving information for a level of the game.
 */
public interface LevelInformation {


    /**
     * the name of the level.
     *
     * @return the name of the level.
     */
    String levelName();

    /**
     * Returns a sprite with the background of the level.
     *
     * @return a sprite representing the background.
     */
    Sprite getBackground();

    /**
     * The Blocks that make up this level, each block contains
     * its size, color and location.
     *
     * @return a list of Blocks.
     */
    Map<Integer, List<Block>> aliensFormation();

    /**
     * the number of the blocks to be removed in order to finish the level.
     *
     * @return a number of blocks.
     */
    int numberOfBlocksToRemove();

    /**
     *
     * @return
     */
    FormationCharge formationCharge();
}
