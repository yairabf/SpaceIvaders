package collidables;

import ballattributes.Ball;
import ballattributes.Velocity;
import gameopperating.GameEnvironment;
import gameopperating.GameLevel;
import geometricshapes.Line;
import geometricshapes.Point;
import geometricshapes.Rectangle;
import listeners.HitListener;
import listeners.HitNotifier;
import sprites.Sprite;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * this class creates a paddle for the game.
 */
public class Paddle implements Sprite, Collidable, HitNotifier {
    private KeyboardSensor keyboard;
    private Rectangle rect;
    private Color color;
    private boolean beenHit;
    private double speed;
    private List<HitListener> hitListeners = new ArrayList<>();
    private GameEnvironment gameEnvironment;

    /**
     * constructor.
     *
     * @param keyboard        the keyboard to control the paddle.
     * @param gameEnvironment the game environment of the paddle.
     */
    public Paddle(KeyboardSensor keyboard, GameEnvironment gameEnvironment) {
        this.rect = new Rectangle(360, 560, 80, 20);
        this.color = Color.orange;
        this.keyboard = keyboard;
        this.speed = 400;
        this.gameEnvironment = gameEnvironment;
        this.beenHit = false;
    }


    /**
     * moves the paddle left.
     *
     * @param dt the game time counter.
     */
    private void moveLeft(double dt) {
        double newX = this.rect.getUpperLeft().getX() - (this.speed * dt);
        if (inBoundaries(newX)) {
            this.rect.setTopLeftX(newX);
        } else {
            this.rect.setTopLeft(new Point(0, this.rect.getUpperLeft().getY()));
        }
    }

    /**
     * moves the paddle right.
     *
     * @param dt the game time counter.
     */
    private void moveRight(double dt) {
        double newX = this.rect.getUpperLeft().getX() + (this.speed * dt);
        if (inBoundaries(newX)) {
            this.rect.setTopLeftX(newX);
        } else {
            this.rect.setTopLeft(new Point(800 - this.rect.getWidth(), this.rect.getUpperLeft().getY()));
        }
    }

    /**
     * checks if the paddle is in the boundries.
     *
     * @param x the x variable to be checked.
     * @return true if in boundaries else false.
     */
    private boolean inBoundaries(double x) {
        return (x + this.rect.getWidth() <= 800 && x >= 0);
    }

    /**
     * activates time passed for paddle.moves the paddle accordingly.
     *
     * @param dt the game time counter.
     */
    @Override
    public void timePassed(double dt) {
        double currentTime = 0;
        if (keyboard.isPressed(keyboard.LEFT_KEY)) {
            this.moveLeft(dt);
        } else if (keyboard.isPressed(keyboard.RIGHT_KEY)) {
            this.moveRight(dt);
        }
        currentTime += dt;
        if (currentTime >= 0.35) {
            if (keyboard.isPressed(keyboard.SPACE_KEY)) {
                this.shootBalls();
            }
        }
    }

    /**
     * draws the paddle on a gives surface.
     *
     * @param d the drawsurface.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(this.color);
        d.fillRectangle((int) this.rect.getUpperLeft().getX(), (int) this.rect.getUpperLeft().getY(),
                (int) this.rect.getWidth(), (int) this.rect.getHeight());
        d.setColor(Color.black);
        d.drawRectangle((int) rect.getUpperLeft().getX(), (int) rect.getUpperLeft().getY(),
                (int) rect.getWidth(), (int) rect.getHeight());
    }

    /**
     * returns the shape.
     *
     * @return the shape rectangle of object.
     */
    public Rectangle getCollisionRectangle() {
        return this.rect;
    }

    /**
     * returns the new velocity of the object that hit the paddle.
     *
     * @param hitter the hitting ball.
     * @return returns the new velocity.
     */
    public void hit(Ball hitter) {
        this.notifyHit(hitter);
        this.beenHit = true;
    }


    /**
     * Add this paddle to the game.
     *
     * @param g the game to be added to.
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
        g.addCollidable(this);
    }

    /**
     * @return
     */
    public boolean isBeenHit() {
        return beenHit;
    }

    /**
     * removes the paddle from the game.
     *
     * @param g the game the paddle should be removed from.
     */
    public void removeFromGame(GameLevel g) {
        g.removeSprite(this);
    }

    /**
     *
     */
    public void shootBalls() {
        double xLocation = this.rect.getUpperLeft().getX() + (this.rect.getWidth() / 2);
        double yLocation = this.rect.getUpperLeft().getY() + 3;
        Point location = new Point(xLocation, yLocation);
        Ball shootingBall = new Ball(location, 5, Color.RED);
        Velocity velocity = Velocity.fromAngleAndSpeed(0, 350);
        shootingBall.setVelocity(velocity);
        shootingBall.setGame(this.gameEnvironment);
    }

    @Override
    public void addHitListener(HitListener hl) {
        this.hitListeners.add(hl);
    }

    @Override
    public void removeHitListener(HitListener hl) {
        this.hitListeners.remove(hl);
    }

    /**
     * @param hitter
     */
    private void notifyHit(Ball hitter) {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<>(this.hitListeners);
        // Notify all listeners about a hit event:
        for (HitListener hl : listeners) {
            hl.hitEvent(this, hitter);
        }
    }
}
