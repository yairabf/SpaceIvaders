package collidables;

import ballattributes.Velocity;
import ballattributes.Ball;
import geometricshapes.Point;
import geometricshapes.Rectangle;

/**
 * interface for objects that can be collide with.
 */
public interface Collidable {
    /**
     * return the "collision shape" of the object.
     *
     * @return the collision shape.
     */
    Rectangle getCollisionRectangle();

    /**
     *
     * @param hitter
     */
    void hit(Ball hitter);


}
